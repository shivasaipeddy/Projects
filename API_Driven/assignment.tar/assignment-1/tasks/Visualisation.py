import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

def visualise(df):

    df['Engine_Size'] = df['Engine_Size'].astype('category')

    # Set the figure size for better visibility
    plt.figure(figsize=(12, 10))

    # Correlation Heatmap (Univariate and Bivariate Analysis)
    corr_matrix = df[['Year', 'Fuel_Type', 'Transmission', 'Mileage', 'Owner_Count', 'Price']].corr()
    print("\nCorrelation Coefficients:")
    print("\nCorrelation Coefficients:\n",corr_matrix)
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
    plt.title("Correlation Heatmap")
    plt.savefig('output/correlation_heatmap.png', format='png')

    # Pairplot (scatterplot matrix) for numerical columns (Bivariate Analysis)
    sns.pairplot(df[['Year', 'Mileage', 'Price', 'Owner_Count']])
    plt.suptitle("Pairplot for Numerical Columns", y=1.02)
    plt.savefig('output/pairplt_numerical_columns.png', format='png')

    # Boxplot for 'Price' to visualize distribution and potential outliers (Univariate Analysis)
    plt.figure(figsize=(8, 6))
    sns.boxplot(x='Fuel_Type', y='Price', data=df)
    plt.title("Boxplot of Price by Fuel Type")
    plt.savefig('output/boxplot_priceVSfueltype.png', format='png')

    # Boxplot for 'Mileage' to visualize distribution and potential outliers (Univariate Analysis)
    plt.figure(figsize=(8, 6))
    sns.boxplot(x='Transmission', y='Mileage', data=df)
    plt.title("Boxplot of Mileage by Transmission")
    plt.savefig('output/boxplot_mileageVStransmission.png', format='png')

    # Countplot for 'Fuel_Type' to visualize the distribution of fuel types (Univariate Analysis)
    plt.figure(figsize=(8, 6))
    sns.countplot(x='Fuel_Type', data=df)
    plt.title("Countplot of Fuel Type")
    plt.savefig('output/countplot_fuelType.png', format='png')

    # Countplot for 'Transmission' to visualize the distribution of transmission types (Univariate Analysis)
    plt.figure(figsize=(8, 6))
    sns.countplot(x='Transmission', data=df)
    plt.title("Countplot of Transmission")
    plt.savefig('output/countplot_transmission.png', format='png')

    # Distribution plot for 'Mileage' (Univariate Analysis)
    plt.figure(figsize=(8, 6))
    sns.histplot(df['Mileage'], kde=True, color='blue', bins=10)
    plt.title("Distribution of Mileage")
    plt.savefig('output/mileage_distribution.png', format='png')

    # Distribution plot for 'Price' (Univariate Analysis)
    plt.figure(figsize=(8, 6))
    sns.histplot(df['Price'], kde=True, color='green', bins=10)
    plt.title("Distribution of Price")
    plt.savefig('output/price_distribution.png', format='png')

    ### Bivariate Analysis ###
    
    # Scatterplot for Mileage vs Price (Bivariate Analysis)
    plt.figure(figsize=(8, 6))
    sns.scatterplot(x='Mileage', y='Price', data=df)
    plt.title("Scatterplot of Mileage vs Price")
    plt.savefig('output/scatterplot_mileageVSprice.png', format='png')

    plt.figure(figsize=(8, 6))
    sns.violinplot(x='Year', y='Owner_Count', data=df)
    plt.title("Violin Plot of Owner Count by Year")
    plt.savefig('output/violin_ownerVSyear.png', format='png')

    plt.figure(figsize=(8, 6))
    sns.violinplot(x='Owner_Count', y='Price', data=df)
    plt.title("Violin Plot of Price by Owner Count")
    plt.savefig('output/violin_priceVSownercount.png', format='png')