import pandas as pd
import numpy as np
import logging


def binning(df):
    # Configure standard Python logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)

    # Distance binning
    min_value = df['Engine_Size'].min()
    max_value = df['Engine_Size'].max()
    logger.info(f"Min Engine Size: {min_value}, Max Engine Size: {max_value}")
    print(f"Min Engine Size: {min_value}, Max Engine Size: {max_value}")

    # Bin size is 5
    bins = np.linspace(min_value, max_value, 5)
    logger.info(f"Bins: {bins}")
    print(f"Bins: {bins}")

    labels = ['standard', 'power', 'heavy', 'high performance']

    # Cut function for distance binning
    df['Engine_Size'] = pd.cut(df['Engine_Size'], bins=bins, labels=labels, include_lowest=True)
    logger.info(f"Distance Binning Results:\n{df['Engine_Size']}")
    print(f"Distance Binning Results:\n{df['Engine_Size']}")

    return df
