
from prefect import flow, task
import BasicStats 
import pandas as pd
import logging
import Binning
import LabelEncoding
import PearsonCorrelation
import Visualisation
import modelMLflow

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Step 2: Load the Dataset
@task(log_prints=True)
def load_dataset():    
    # Load the dataset
    df = pd.read_csv("data/car_price_dataset.csv")
    print("Dataset loaded successfully")
    logger.info("Dataset loaded successfully.")
    logger.info(f"DataFrame head:\n{df.head()}")

    return df

# Step 3: Basic Stats and Feature Selection
@task(log_prints=True)
def BasicStat(df):
    return BasicStats.process_data(df)

# Step 3: Data Preprocessing
@task(log_prints=True)
def preprocess_data(df):
    df = Binning.binning(df)

    df = LabelEncoding.labelEncoding(df)

    #Normalization of the 'Mileage' feature'
    df['Mileage'] = (df['Mileage'] - df['Mileage'].min()) / (df['Mileage'].max() - df['Mileage'].min())

    PearsonCorrelation.correlation(df)

    logger.info(f"\n{df.dtypes}")

    Visualisation.visualise(df)

    return df

# Step 4: Model Training
@task(log_prints=True)
def train_model(df):
    #model.model(df)
    modelMLflow.model(df)

# Step 5: Define Prefect Flow
@flow(log_prints=True)
def car_price_prediction():

    # step 1 = loading data
    df1 = load_dataset()
    
    # step 2 = BasicStats and Feature Selection
    df2 = BasicStat(df1,wait_for=[df1])

    # step 3 = preprocessing
    df3 = preprocess_data(df2,wait_for=[df2])
    
    # step 4 = data modeling
    train_model(df3,wait_for=[df3])
   
# Step 6: Run the Prefect Flow
if __name__ == "__main__":
    car_price_prediction.serve(name="car-price_prediction-workflow",
                      tags=["first workflow"],
                      parameters={},
                      interval=180) #3 minutes
