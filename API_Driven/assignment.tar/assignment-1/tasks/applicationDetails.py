from prefect import get_client
from prefect.client.schemas.filters import FlowFilter, FlowRunFilter, FlowRunFilterDeploymentId
from uuid import UUID

# Connect to Prefect Cloud (or Prefect Server if you're using it locally)
async def main():
    async with get_client() as client:
        # Your code to interact with the client goes here

        # Example 1: Retrieve all flows in the current Prefect workspace
        flows = await client.read_flows(flow_filter=FlowFilter())

        # Display the flow details
        print("Flows in the current workspace:")
        for flow in flows:
            print(f"Flow ID: {flow.id}, Name: {flow.name}, Description: {flow.tags}, Created: {flow.labels}")

        deployments = await client.read_deployments()  # Correct method for Prefect 2.x

        # Display details of all deployments
        print("\nDeployments in the current workspace:")
        for deployment in deployments:
            print(f"Deployment Name: {deployment.name}")
            print(f"Deployment ID: {deployment.id}")
            print(f"Flow ID: {deployment.flow_id}")
            print(f"Labels: {deployment.labels}")
            print(f"Status: {deployment.status}")
            print(f"Created at: {deployment.created}")
            print(f"Updated at: {deployment.updated}")
            print("-" * 40)


            # Construct a FlowRunFilter with properly structured deployment_id
            flow_run_filter = FlowRunFilter(deployment_id=FlowRunFilterDeploymentId(deployment_id=deployment.id))

            # Fetch all the runs for this deployment using the flow_run_filter
            flow_runs = await client.read_flow_runs(flow_run_filter=flow_run_filter)

            # Display details of all flow runs associated with the deployment
            print(f"Runs for Deployment: {deployment.name}")
            for flow_run in flow_runs:
                print(f"Flow Run ID: {flow_run.id}")
                print(f"Flow Run Name: {flow_run.name}")
                print(f"Status: {flow_run.state}")
                print(f"Start Time: {flow_run.start_time}")
                print(f"End Time: {flow_run.end_time}")
                print(f"Duration: {flow_run.total_run_time}")
                print("-" * 40)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
