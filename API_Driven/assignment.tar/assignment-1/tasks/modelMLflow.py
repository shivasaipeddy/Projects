import mlflow
import mlflow.sklearn
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

def model(df):
    df['Engine_Size'] = df['Engine_Size'].cat.codes  # Convert categorical to numerical values

    # Define feature columns and target variable (Price)
    X = df.drop(columns=['Price'])  # Features (excluding non-numeric columns)
    y = df['Price']  # Target (Price)

    # Split the data into training and testing sets (70% train, 30% test)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Initialize the models
    models = {
        'Linear Regression': LinearRegression(),
        'Random Forest Regressor': RandomForestRegressor(),
        'Gradient Boosting Regressor': GradientBoostingRegressor(),
        'XGBoost Regressor': XGBRegressor()
    }

    # Start an MLflow run
    with mlflow.start_run():
        # Log parameters (e.g., model names)
        mlflow.log_param("Data_Split", "70-30 Train-Test")

        # Training and evaluation for each model
        results = {}

        for model_name, model in models.items():
            # Train the model
            model.fit(X_train, y_train)

            # Predict on the test set
            y_pred = model.predict(X_test)

            # Calculate evaluation metrics
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            mae = mean_absolute_error(y_test, y_pred)
            rmse = mse ** 0.5  # Root Mean Squared Error

            # Log metrics for the model
            mlflow.log_metric(f"{model_name}_MSE", mse)
            mlflow.log_metric(f"{model_name}_R2", r2)
            mlflow.log_metric(f"{model_name}_MAE", mae)
            mlflow.log_metric(f"{model_name}_RMSE", rmse)

            # Store results for determining best model
            results[model_name] = {'MSE': mse, 'R2': r2}

            # Create an example input (first row of the feature data)
            input_example = X_train.iloc[0:1]

            # Log the model with an input example to avoid the warning
            mlflow.sklearn.log_model(model, f"{model_name}_model", input_example=input_example)

            print(f"{model_name} - MSE: {mse:.2f}, R-squared: {r2:.2f}, MAE: {mae:.2f}, RMSE: {rmse:.2f}")

        # Identify the best model based on R-squared or MSE
        best_model_name = max(results, key=lambda x: results[x]['R2'])  # Or use 'MSE' for selecting best
        print(f"Best model based on R-squared: {best_model_name}")

        # Log the best model name to MLflow
        mlflow.log_param("Best_Model", best_model_name)

