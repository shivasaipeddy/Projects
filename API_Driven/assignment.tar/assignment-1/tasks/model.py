import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error


def model(df):
    df['Engine_Size'] = df['Engine_Size'].cat.codes  # Convert categorical to numerical values

    # Define feature columns and target variable (Price)
    X = df.drop(columns=['Price'])  # Features (excluding non-numeric columns)
    y = df['Price']  # Target (Price)

    # Split the data into training and testing sets (70% train, 30% test)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Initialize the models
    models = {
        'Linear Regression': LinearRegression(),
        'Random Forest Regressor': RandomForestRegressor(),
        'Gradient Boosting Regressor': GradientBoostingRegressor(),
        'XGBoost Regressor': XGBRegressor()
    }

    # Training and evaluation for each model
    results = {}

    for model_name, model in models.items():
        # Train the model
        model.fit(X_train, y_train)
        
        # Predict on the test set
        y_pred = model.predict(X_test)
        
        # Calculate evaluation metrics
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        mae = mean_absolute_error(y_test, y_pred)
        rmse = mse ** 0.5  # Root Mean Squared Error
        # Store results
        results[model_name] = {'MSE': mse, 'R2': r2}
        
        print(f"{model_name} - MSE: {mse:.2f}, R-squared: {r2:.2f}, MAE: {mae:.2f}, RMSE: {rmse:.2f}")

    # Identify the best model based on R-squared or MSE
    best_model_name = max(results, key=lambda x: results[x]['R2'])  # Or use 'MSE' for selecting best
    print(f"Best model based on R-squared: {best_model_name}")
