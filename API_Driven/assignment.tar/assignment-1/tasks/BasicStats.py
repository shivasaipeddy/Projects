import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import logging


def process_data(df):
    # Configure standard logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)

    #feature selection, removing of unrequired features
    df = df.drop('Doors', axis=1)
    df = df.drop('Model', axis=1)

    # Summary statistics
    logger.info("Summary Statistics:")
    print("Summary Statistics")

    # Checking for missing values
    logger.info("Missing Values:")
    logger.info(f"\n{df.isnull().sum()}")

    print("Missing values:\n",df.isnull().sum())

    # Data type information
    logger.info("Data Types:")
    logger.info(f"\n{df.dtypes}")

    print("DataTypes:\n",df.dtypes)

    return df
